<!DOCTYPE html>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<html>
<head>
<meta charset="UTF-8">
<title>Send Request | UPSMP</title>

<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
	rel="stylesheet">

<style>
body {
	background-color: #f5f7fa;
}

.card {
	border-radius: 10px;
	box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}
</style>

</head>
<body>

	<%
	
	int uId = 0;
	String name = "";

	if(session.getAttribute("userId") != null){
	    uId = Integer.parseInt(session.getAttribute("userId").toString());
	    name = session.getAttribute("userName").toString();
	    /* System.out.println(uId);
	    System.out.println(name); */
	    
	}else{
	    out.println("Session expired. Please login again.");
	    return;
	}
	
	
	
	String pId = request.getParameter("problemId");
	int problemId = Integer.parseInt(pId);
	/* String p_title = request.getParameter("title");
	String p_description = request.getParameter("description"); */
	
	/* System.out.println(problemId);
 	System.out.println(p_title);
 	System.out.println(p_description); */
	%>

	<!-- HEADER -->
	<section class="py-4 bg-white border-bottom">
		<div
			class="container d-flex justify-content-between align-items-center">
			<h2 class="fw-bold text-primary mb-0">Project Info</h2>
			<button class="btn btn-outline-secondary" onclick="history.back()">Back</button>
		</div>
	</section>

	<%
	try {

		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "upsmp", "upsmp");
		PreparedStatement ps = con.prepareStatement("select problem_id,title,description,status from problem where problem_id=?");
		ps.setInt(1, problemId);

		// System.out.println("working");
		ResultSet rs = ps.executeQuery();

		if (rs.next()) {
			int prob_Id = rs.getInt(1);
			// System.out.println(request.getQueryString());
	%>
	
	<form action="./send_request_controller.jsp" method="post">
	
	<!-- PART 2 : STUDENT INFO -->
	<section class="container my-5">
		<div class="card data-card p-4">
			<h4 class="fw-bold text-primary mb-4">Student Information</h4>
			<div class="row g-3">
				<div class="col-md-4">
					<label class="form-label">Student ID</label> 
						<input type="text" class="form-control" name="uId" value="<%=uId%>"  disabled>
						<input type="hidden" name="uId" value="<%=uId%>">
				</div>

				<div class="col-md-4">
					<label class="form-label">Student Name</label> 
						<input type="text" class="form-control" name="name" value="<%=name%>"  disabled>
						<input type="hidden" name="name" value="<%=name%>">
				</div>
			</div>
		</div>
	</section>

	<!-- PROJECT INFO -->
	<section class="container my-5">
		<div class="card p-4">
			<h4 class="fw-bold text-primary mb-4">Project Details</h4>

			<div class="row g-3">
				<div class="col-md-4">
					<label class="form-label">Project ID</label> <input type="text"
						class="form-control" name="problemId" value="<%=rs.getInt(1)%>" disabled>
						<input type="hidden" name="problemId" value="<%=rs.getInt(1)%>">
				</div>

				<div class="col-md-8">
					<label class="form-label">Project Title</label> <input type="text"
						class="form-control" name="title" value="<%=rs.getString(2)%>" disabled>
				</div>

				<div class="col-12">
					<label class="form-label">Project Description</label>
					<textarea class="form-control" name="description" rows="4" disabled>
                		<%=rs.getString(3)%>
              </textarea>
				</div>
				
				<div class="col-md-8">
					<label class="form-label">Project Status</label> <input type="text"
						class="form-control" name="status" value="<%=rs.getString(4)%>" disabled>
				</div>
				
			</div>
		</div>
	</section>

	<!-- SOLUTION SECTION -->
	<section class="container mb-5">
		<div class="card p-4">
			<h4 class="fw-bold text-primary mb-4">Submit Your Solution</h4>

			<textarea class="form-control" rows="6" name="solution"
				placeholder="Write your solution here..."></textarea>
		</div>
	</section>

	<!-- ACTION BUTTONS -->
	<section class="container mb-5">
		<div class="d-flex justify-content-end gap-3">
			<button class="btn btn-outline-secondary" onclick="history.back()">Back</button>
			<button class="btn btn-primary px-4" onclick="sendRequest()">Send
				Request</button>
		</div>
	</section>
	</form>
	<%
	}
	} catch (Exception e) {
	e.printStackTrace();
	}
	%>

	<!-- FOOTER -->
	<footer class="bg-dark text-white text-center py-3">
		<small>&copy; 2026 UPSMP. All Rights Reserved.</small>
	</footer>

	<script>
function sendRequest() {
    alert("Request Sent Successfully!");
}
</script>

</body>
</html>