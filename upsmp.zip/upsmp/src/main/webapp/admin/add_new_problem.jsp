<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Add New problems | UPSMP</title>

<!-- Bootstrap & Icons -->
<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
	rel="stylesheet">
<link
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
	rel="stylesheet">

<!--CSS Link-->
<link rel="stylesheet" href="../CSS/add_new_students.css" />

</head>
<body>

	<!-- HEADER -->
	<header class="header-top">
		<div class="container d-flex align-items-center">
			<img
				src="https://surl.li/lmwgup"
				width="55" class="me-3">
			<h2 class="mb-0 fw-bold" style="color: var(--primary-color);">UPSMP</h2>
		</div>
	</header>

	<!-- ROLE -->
	<section class="role-banner">
		<div class="container">
			<h5 class="mb-0">
				Welcome, Admin <span class="fw-normal">(Admin)</span>
			</h5>
		</div>
	</section>

	<!-- LAYOUT -->
	<div class="container-fluid">
		<div class="row">

			<!-- SIDEBAR -->
			<div class="col-md-3 col-lg-2 sidebar p-0">
			
				<a href="./my_problms.jsp" class="active"> <i class="fas fa-chart-line me-2"></i> My Problems </a> 
				
				<a href="./view_all_problems.jsp"> <i class="fas fa-folder-open me-2"></i> All Projects </a>
					
				<a href="./view_all_hod.jsp" class="#"> <i class="fa-solid fa-user-tie me-2"></i> HOD </a>
				
				<a href="./view_all_students.jsp" class="#"> <i class="fa-solid fa-user-graduate me-2"></i> Students </a>
					
				 <a href="./view_all_submitted_solutions.jsp"> <i class="fa-solid fa-lightbulb me-2"></i> Solution Submitted  </a>
					
				 <a href="./Login.html"> <i class="fas fa-sign-out-alt me-2"></i> Logout </a>
				 
			</div>


			<!-- CONTENT -->
			<div class="col-md-9 col-lg-10 content-area">

				<h4 class="fw-bold text-primary mb-4">Add New Problem</h4>

				<div class="form-card">

					<form action="add_new_problem_controller.jsp" method="post">

						<!-- TITLE -->

						<div class="mb-3">
							<label class="form-label">Title</label> <input type="text"
								class="form-control" name="title"
								placeholder="Enter Problem Title" required>
						</div>


						<!-- DESCRIPTION -->

						<div class="mb-3">
							<label class="form-label">Description</label>

							<textarea class="form-control" name="description" rows="4"
								placeholder="Enter Problem Description" required></textarea>

						</div>

						<!-- PROBLEM TYPE -->
						<div class="mb-3">

							<label class="form-label">Problem Type</label> <select
								class="form-control" name="problem_type" id="problemType"
								onchange="toggleDepartment()">

								<option value="">Select Type</option>
								<option value="University">University</option>
								<option value="Department">Department</option>

							</select>

						</div>


						<!-- DEPARTMENT -->

						<div class="mb-4">

							<label class="form-label">Department Name</label> <select
								class="form-control" name="department" id="departmentSelect"
								disabled>

								<option value="">Select Department</option>

								<option value="MCA">MCA</option>
								<option value="MBA">MBA</option>
								<option value="B.Tech">B.Tech</option>
								<option value="B.Sc">B.Sc</option>
								<option value="B.Com">B.Com</option>

							</select>

						</div>
						
						<!-- <div class="mb-3">
							<label class="form-label">Status</label> <input type="text"
								class="form-control" name="status"
								placeholder="Enter Problem Status" required>
						</div>
 -->

						<!-- BUTTONS -->

						<button type="submit" class="btn btn-primary me-2">

							<i class="fa-solid fa-save me-1"></i> Add Problem

						</button>


						<a href="view_all_problems.jsp" class="btn btn-secondary"> <i
							class="fa-solid fa-arrow-left me-1"></i> Back

						</a>
					</form>
				</div>
			</div>
		</div>
	</div>


	<!-- JAVASCRIPT -->

	<script>
		function toggleDepartment() {

			let type = document.getElementById("problemType").value;

			let dept = document.getElementById("departmentSelect");

			if (type === "Department") {

				dept.disabled = false;

			} else {

				dept.disabled = true;

				dept.value = "";

			}

		}
	</script>


	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


</body>
</html>