<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Delete HOD Details Controllers | UPSMP</title>
</head>
<body>

<%
	String userId = request.getParameter("hodId");
	int hodId = Integer.parseInt(userId);
	String s_name = request.getParameter("name");
	String s_email = request.getParameter("email");
	String s_password = request.getParameter("password");
	String s_role = request.getParameter("role");
	String s_department = request.getParameter("dept_name");
	String mobile_no = request.getParameter("mobile_number");
	String s_address = request.getParameter("address");
	String s_gender = request.getParameter("gender");
	/* System.out.println(userId);
	System.out.println(hodId);
	System.out.println(s_name);
	System.out.println(s_email);
	System.out.println(s_password);
	System.out.println(s_role);
	System.out.println(s_department);
	System.out.println(mobile_no);
	System.out.println(s_address);
	System.out.println(s_gender); */
	
		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
			PreparedStatement ps = con.prepareStatement("delete from users where user_id =?");
			ps.setInt(1, hodId);
			/* ps.setString(2, s_name);
			ps.setString(3, s_email);
			ps.setString(4, s_password);
			ps.setString(5, s_role);
			ps.setString(6, s_department);
			ps.setString(7, mobile_no);
			ps.setString(8, s_address);
			ps.setString(9, s_gender);  */
			
			int i = ps.executeUpdate();
			
			if (i>0){
				response.sendRedirect("view_all_hod.jsp?msg=HOD deleted Successfully&color=green");
			} else {
				response.sendRedirect("view_all_hod.jsp?msg=HOD delition failed&color=red");
			}
			
			con.close();
		} catch(Exception e){e.printStackTrace();
			response.sendRedirect("view_all_hod.jsp?msg=HOD delition failed&color=red");
		}
	%>

</body>
</html>