<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Add_New_HOD_Controller | UPSMP</title>
</head>
<body>

	<%
		
		/* String user_id = request.getParameter("hod_id");
		int hod_id = Integer.parseInt(user_id); */
		String h_name = request.getParameter("name");
		String h_email = request.getParameter("email");
		String h_password = request.getParameter("password");
		String h_role = request.getParameter("role");
		String h_department = request.getParameter("department");
		String mobile_no = request.getParameter("mobile");
		String h_address = request.getParameter("address");
		String h_gender = request.getParameter("gender");

		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
			PreparedStatement ps = con.prepareStatement("insert into users values(user_id_seq.nextval,?,?,?,?,?,?,?,?)");
			
			ps.setString(1, h_name);
			ps.setString(2, h_email);
			ps.setString(3, h_password);
			ps.setString(4, h_role);
			ps.setString(5, h_department);
			ps.setString(6, mobile_no);
			ps.setString(7, h_address);
			ps.setString(8, h_gender);
			
			int i = ps.executeUpdate();
			
			if (i>0){
				response.sendRedirect("view_all_hod.jsp?msg=Hod Added Successfully&color=green");
			} else {
				response.sendRedirect("view_all_hod.jsp?msg=Hod Adding Failed&color=red");
				}
			
			con.close();
		}catch(Exception e){e.printStackTrace();
		response.sendRedirect("view_all_hod.jsp?msg=Hod Adding Failed&color=red");
		}
		
		
	%>

</body>
</html>