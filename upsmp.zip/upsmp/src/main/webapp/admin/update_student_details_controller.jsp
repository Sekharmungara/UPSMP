<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Update Student Details Controller | UPSMP</title>

	<!-- Bootstrap & Icons -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
	
	<!--CSS Link-->
	<link rel="stylesheet" href="../CSS/view_student_details.css" />
	
</head>
<body>

<%
	String userId = request.getParameter("studentId");
	int studentId = Integer.parseInt(userId);
	String s_name = request.getParameter("name");
	String s_email = request.getParameter("email");
	String s_password = request.getParameter("password");
	String s_role = request.getParameter("role");
	String s_department = request.getParameter("dept_name");
	String mobile_no = request.getParameter("mobile_number");
	String s_address = request.getParameter("address");
	String s_gender = request.getParameter("gender");
/* 	System.out.println(userId);
	System.out.println(studentId);
	System.out.println(s_name);
	System.out.println(s_email);
	System.out.println(s_password);
	System.out.println(s_role);
	System.out.println(s_department);
	System.out.println(mobile_no);
	System.out.println(s_address);
	System.out.println(s_gender); */
	
		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
			PreparedStatement ps = con.prepareStatement("update users set name =?, email =?, password =?, role =?, dept_name =?, mobile_number =?, address =?, gender =? where user_id =?");
			
			ps.setString(1, s_name);
			ps.setString(2, s_email);
			ps.setString(3, s_password);
			ps.setString(4, s_role);
			ps.setString(5, s_department);
			ps.setString(6, mobile_no);
			ps.setString(7, s_address);
			ps.setString(8, s_gender);
			ps.setInt(9, studentId);
			
			int i = ps.executeUpdate();
			
			if (i>0){
				response.sendRedirect("view_all_students.jsp?msg=Student updated Successfully&color=green");
			} else {
				response.sendRedirect("view_all_students.jsp?msg=Student updation failed&color=red");
			}
			
			con.close();
		} catch(Exception e){e.printStackTrace();
			response.sendRedirect("view_all_students.jsp?msg=Student updation failed&color=red");
		}
	%>
	
</body>
</html>