<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Update HOD Details | UPSMP</title>

	<!-- Bootstrap & Icons -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
	
	<!--CSS Link-->
	<link rel="stylesheet" href="../CSS/view_student_details.css" />
	
</head>
<body>

<%
	String userId = request.getParameter("hodId");
	int hodId = Integer.parseInt(userId); 
	//System.out.println(userId);


%>
	<!-- HEADER -->
	<header class="header-top">
		<div class="container d-flex align-items-center">
			<img
				src="https://surl.li/lmwgup"
				width="55" class="me-3">
			<h2 class="mb-0 fw-bold" style="color: var(--primary-color)">UPSMP</h2>
		</div>
	</header>

	<!-- ROLE -->
	<section class="role-banner">
		<div class="container">
			<h5 class="mb-0">
				Welcome, Admin <span class="fw-normal">(Admin)</span>
			</h5>
		</div>
	</section>

	<!-- MAIN -->
	<div class="container-fluid">
		<div class="row">

			<!-- SIDEBAR -->
			<div class="col-md-3 col-lg-2 sidebar p-0">

				<a href="./my_problems.jsp"> <i class="fas fa-chart-line me-2"></i> My Problems </a> 
				
				<a href="./view_all_problems.jsp"> <i class="fas fa-folder-open me-2"></i> All Projects </a>
					
				<a href="./view_all_hod.jsp" class="active"> <i class="fa-solid fa-user-tie me-2"></i> HOD </a>
				
				<a href="./view_all_students.jsp" class="#"> <i class="fa-solid fa-user-graduate me-2"></i> Students </a>
					
				 <a href="./view_all_submitted_solutions.jsp"> <i class="fa-solid fa-lightbulb me-2"></i> Solution Submitted  </a>
					
				 <a href="./Login.html"> <i class="fas fa-sign-out-alt me-2"></i> Logout </a>

			</div>
		<%
	
		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
			PreparedStatement ps = con.prepareStatement("select * from users where user_id=?");
			ps.setInt(1, hodId);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				int user_id = rs.getInt(1); %>
				<!-- CONTENT -->
					<div class="col-md-9 col-lg-10 content-area">

					<div class="d-flex justify-content-between align-items-center mb-4">
						<h4 class="fw-bold text-primary">Student Details</h4>
					</div>

					<div class="card data-card p-4">
				
					<form action="./update_hod_details_controller.jsp" method="post">

						<div class="row mb-4">
							<div class="col-md-6">
								<label class="form-label">HOD ID</label> <input type="text"
									class="form-control" name="hodId" value="<%=rs.getInt(1) %>" >
							</div>

							<div class="col-md-6">
								<label class="form-label">HOD Name</label> <input
									type="text" class="form-control" name="name" value="<%=rs.getString(2) %>" >
							</div>
							
							<div class="col-md-6">
								<label class="form-label">Email</label> <input type="email"
									class="form-control" name="email" value="<%=rs.getString(3) %>" >
							</div>
							
							<div class="col-md-6">
								<label class="form-label">Password</label> <input type="text"
									class="form-control" name="password" value="<%=rs.getString(4) %>" >
							</div>
						</div>

						<div class="row mb-4">
							
							<div class="col-md-6">
								<label class="form-label">Role</label> <input type="text"
									class="form-control" name="role" value="<%=rs.getString(5) %>" >
							</div>
							
							
							<div class="col-md-6">
								<label class="form-label">Department</label> <input type="text"
									class="form-control" name="dept_name" value="<%=rs.getString(6) %>" >
							</div>

							
						</div>

						<div class="row mb-3">

							<div class="col-md-6">
								<label class="form-label">Mobile</label> <input type="text"
									class="form-control" name="mobile_number" value="<%=rs.getString(7) %>" >
							</div>

							<div class="col-md-6">
								<label class="form-label">Address</label> <input type="text"
									class="form-control" name="address" value="<%=rs.getString(8) %>" >
							</div>
							
							<div class="col-md-6">
								<label class="form-label">Gender</label> <input type="text"
									class="form-control" name="gender" value="<%=rs.getString(9) %>" >
							</div>

						</div>

						<div class="mt-4">

							<a href="./view_all_hod.jsp" class="btn btn-secondary"> <i
								class="fa-solid fa-arrow-left me-2"></i>Back
							</a>
							
							<a href="./update_hod_details_controller.jsp"></a><button type="submit" class="btn btn-primary">
							<i class="fa-solid fa-pen-to-square me-2"></i>Update
							</button>
						</div>

					</form>

				</div>

			</div>
		</div>
	</div>
			<% }
			
		} catch(Exception e){e.printStackTrace();}
			%>
			
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>