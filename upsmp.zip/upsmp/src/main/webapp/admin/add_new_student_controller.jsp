<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Add-New-Student-Controller | UPSMP</title>
</head>
<body>

	<%
		
		/* String user_id = request.getParameter("student_id");
		int student_id = Integer.parseInt(user_id); */
		String s_name = request.getParameter("name");
		String s_email = request.getParameter("email");
		String s_password = request.getParameter("password");
		String s_role = request.getParameter("role");
		String s_department = request.getParameter("department");
		String mobile_no = request.getParameter("mobile");
		String s_address = request.getParameter("address");
		String s_gender = request.getParameter("gender");

		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
			PreparedStatement ps = con.prepareStatement("insert into users values(user_id_seq.nextval,?,?,?,?,?,?,?,?)");
			
			ps.setString(1, s_name);
			ps.setString(2, s_email);
			ps.setString(3, s_password);
			ps.setString(4, s_role);
			ps.setString(5, s_department);
			ps.setString(6, mobile_no);
			ps.setString(7, s_address);
			ps.setString(8, s_gender);
			
			int i = ps.executeUpdate();
			
			if (i>0){
				response.sendRedirect("view_all_students.jsp?msg=Student added Successfully&color=green");
			} else {
				response.sendRedirect("view_all_students.jsp?msg=Student adding failed&color=red");
			}
			
			con.close();
		}catch(Exception e){e.printStackTrace();
			response.sendRedirect("view_all_students.jsp?msg=Student adding failed&color=red");
		}
		
		
	%>



</body>
</html>