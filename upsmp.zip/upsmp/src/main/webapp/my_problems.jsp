<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>My Problems | UPSMP</title>

<!-- Bootstrap & Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"	rel="stylesheet">

<!--CSS Link-->
<link rel="stylesheet" href="./CSS/view_all_hod.css" />

</head>
<body>


	<%
	
    int userId = 0;

    if(session.getAttribute("userId") != null){
        userId = Integer.parseInt(session.getAttribute("userId").toString());
    } else {
        response.sendRedirect("../Login.html");
    }
    
	%>

	<!-- ===== PART 1: PROJECT TITLE ===== -->
	<header class="header-top">
		<div class="container d-flex align-items-center">
			<img src="https://surl.li/lmwgup"
				width="55" class="me-3" alt="Logo">
			<h2 class="mb-0 fw-bold" style="color: var(--primary-color);">
				UPSMP</h2>
		</div>
	</header>

	<!-- ===== PART 2: WELCOME ADMIN ===== -->
	<section class="role-banner">
		<div class="container">
			<h5 class="mb-0">
				Welcome, Student <span class="fw-normal">(Student)</span>
			</h5>
		</div>
	</section>

	<!-- ===== PART 3: MAIN LAYOUT ===== -->
	<div class="container-fluid">
		<div class="row">
			<!-- LEFT SIDEBAR -->
			<div class="col-md-3 col-lg-2 sidebar p-0">
				<a href="#" class="active"> 
					<i class="fas fa-chart-line me-2"></i>My Projects</a>
					
				 <a href="./view_all_problems.jsp" class="#"> 
					<i class="fas fa-folder-open me-2"></i> All Projects </a>
				
				 <a href="./Login.html" class="#"> 
					<i class="fas fa-sign-out-alt me-2"></i> Logout </a>
			</div>

			<%
	
		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection  con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
			PreparedStatement ps = con.prepareStatement("select problem_id, title, status from assigned_problems where student_id=?");
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			//System.out.println("successfull");
			%>
			<!-- RIGHT CONTENT AREA -->

			<div class="col-md-9 col-lg-10 content-area">

				<!-- PAGE HEADER -->
				<div class="d-flex justify-content-between align-items-center mb-4">
					<h4 class="fw-bold text-primary">My Problems</h4>
					         
                <%
                		String message = request.getParameter("msg") == null ? "" : request.getParameter("msg");
                		String color = request.getParameter("color") == null ? "" : request.getParameter("color");
                	%>
                
                	<div>
                		<h6 style="color:<%=color%>;"><%=message %></h6>
                	</div>
                
				</div>

				<!-- HOD TABLE -->
				<div class="card data-card p-4">
					<div class="table-responsive">
						<table class="table table-bordered align-middle">
							<thead class="table-light">
								<tr>
									<th>Problem Id</th>
									<th>Title</th>
									<th>Status</th>
									<th class="text-center">Actions</th>
								</tr>
							</thead>

							<% // System.out.println("successfull");
			while(rs.next()){%>

							<tr>
								<td><%=rs.getInt(1) %></td>
								<td><%=rs.getString(2) %></td>
								<td><%=rs.getString(3) %></td>
								<td class="text-center">
								
								 <a href="./view_problem_details.jsp?problemId=<%=rs.getInt(1) %>"><i
										class="fa-solid fa-eye action-icon view" title="View"></i></a>
										
										 <a href="./update_problem_details.jsp?problemId=<%=rs.getInt(1) %>">
										<i class="fa-solid fa-pen-to-square action-icon edit" title="Update"></i></a>
								</td>
							</tr>
							<% } %>
						</table>
						<% con.close();
		} catch (Exception e) {e.printStackTrace();}
	
	%>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>