<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Update Problem Details | UPSMP</title>

	<!-- Bootstrap & Icons -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
	
	<!--CSS Link-->
	<link rel="stylesheet" href="./CSS/view_student_details.css" />
	
</head>
<body>

<%
	String problem_id = request.getParameter("problemId");
	int problemId = Integer.parseInt(problem_id); 
	// System.out.println(userId);


%>
	<!-- HEADER -->
	<header class="header-top">
		<div class="container d-flex align-items-center">
			<img src="https://surl.li/lmwgup"
				width="55" class="me-3">
			<h2 class="mb-0 fw-bold" style="color: var(--primary-color)">UPSMP</h2>
		</div>
	</header>

	<!-- ROLE -->
	<section class="role-banner">
		<div class="container">
			<h5 class="mb-0">
				Welcome, Student <span class="fw-normal">(Student)</span>
			</h5>
		</div>
	</section>

	<!-- MAIN -->
	<div class="container-fluid">
		<div class="row">

		<!-- LEFT MENU -->
        <div class="col-md-3 col-lg-2 sidebar p-0">
        
            <a href="./my_problems.jsp" class="#" onclick="loadDashboard()"> <i class="fas fa-chart-line me-2"></i> My Projects </a>
                
            <a href="./view_all_problems.jsp" class="#" onclick="loadProjects()"> <i class="fas fa-folder-open me-2"></i> All Projects </a>
                
            <a href="./Login.html" onclick="loadProjects()"> <i class="fas fa-sign-out-alt me-2"></i> Logout </a>
            
        </div>

		<%
	
		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
			PreparedStatement ps = con.prepareStatement("select problem_id,title,description,prob_type,dept_name,status from problem where problem_id=?");
			ps.setInt(1, problemId);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				int problems_id = rs.getInt(1); %>
				<!-- CONTENT -->
					<div class="col-md-9 col-lg-10 content-area">

					<div class="d-flex justify-content-between align-items-center mb-4">
						<h4 class="fw-bold text-primary">Problem Details</h4>
					</div>

					<div class="card data-card p-4">
				
					<form action="./update_problem_details_controller.jsp" method="post">

						<div class="row mb-4">
							<div class="col-md-6">
								<label class="form-label">Problem ID</label> <input type="text"
									class="form-control" name="problemId" value="<%=rs.getInt(1) %>" disabled>
									<input type="hidden" name="problemId" value="<%=rs.getInt(1) %>">
							</div>

							<div class="col-md-6">
								<label class="form-label">Title</label> <input
									type="text" class="form-control" name="title" value="<%=rs.getString(2) %>" disabled>
							</div>
							
							<div class="col-md-6">
								<label class="form-label">Description</label>
								<%-- <input type="text" class="form-control" value="<%=rs.getString(3) %>" disabled> --%>
								 
								 <textarea class="form-control" name="description" rows="4" disabled> <%=rs.getString(3) %> </textarea>
								 
							</div>
							
							<div class="col-md-6">
								<label class="form-label">Problem Type</label> <input type="text"
									class="form-control" name="problem_type" value="<%=rs.getString(4) %>" disabled>
							</div>
						</div>

						<div class="row mb-4">
							
							<div class="col-md-6">
								<label class="form-label">Department Name</label> <input type="text"
									class="form-control" name="department" value="<%=rs.getString(5) %>" disabled>
							</div>
							
							
							<%-- <div class="col-md-6">
								<label class="form-label">Status</label> <input type="text"
									class="form-control" name="status" value="<%=rs.getString(6) %>" >
							</div> --%>
							
							
							<div class="col-md-6">
    							<label class="form-label">Status</label>
    							<select class="form-select" name="status">
        						<option value="TO DO" <% if("TO DO".equals(rs.getString(6))){ %> selected="selected"<%} %>>TO DO</option>
        						<option value="INPROGRESS" <% if("INPROGRESS".equals(rs.getString(6))){ %> selected="selected"<%} %>>INPROGRESS</option>
        						<option value="COMPLETED" <% if("COMPLETED".equals(rs.getString(6))){ %> selected="selected"<%} %>>COMPLETED</option>
   	 							</select>
							</div>

							
						</div>

						<div class="mt-4">

							<a href="./view_all_problems.jsp.jsp" class="btn btn-secondary"> <i
								class="fa-solid fa-arrow-left me-2"></i>Back
							</a>
							
							<a href="./update_problem_details_controller.jsp"></a><button type="submit" class="btn btn-primary">
							<i class="fa-solid fa-pen-to-square me-2"></i>Update
							</button>
							
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<% }
			
		} catch(Exception e){e.printStackTrace();}
			%>
			
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>