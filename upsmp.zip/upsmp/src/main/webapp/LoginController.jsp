<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Login Controller | UPSMP</title>
</head>
<body>
<%

	String email = request.getParameter("email");
	String password = request.getParameter("password");
	String role = request.getParameter("role");
	
	/* System.out.println("email"+ email);
	System.out.println("password"+ password);
	System.out.println("role"+ role);
 */
	try {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
		PreparedStatement ps = con.prepareStatement("Select * from users where email=? and password=? and role=?");
		ps.setString(1, email);
		ps.setString(2, password);
		ps.setString(3, role);
		
		ResultSet rs = ps.executeQuery();
		
		String redirectPath = "";
		int userId = 0;
		String userName = "";
		
		if(rs.next()){
			
			userId = rs.getInt(1);
			userName = rs.getString(2);
			
			session.setAttribute("userId", userId);
			session.setAttribute("userName", userName);
			
			//System.out.println("Successfull");

			

			
	    	if(role.equals("Admin")){
	        	//response.sendRedirect("admin/admin_dashboard.html");
	    		redirectPath = "admin/admin_dashboard.html";
	    	}
	    	else if(role.equals("HOD")){
	        	//response.sendRedirect("HOD/HOD_Dashboard.html");
	    		redirectPath = "HOD/HOD_Dashboard.html";
	    	}
	    	else if(role.equals("Student")){
	        	//response.sendRedirect("Student_Dashborad.jsp");
	    		redirectPath = "Student_Dashborad.jsp";
	    	}
	    	
	    	response.sendRedirect(redirectPath);
	    	
	    	

		}else{

			out.println("Invalid Login");
			response.sendRedirect("Login.html");

		}
		
	}catch(Exception e){e.printStackTrace();}


%>
</body>
</html>