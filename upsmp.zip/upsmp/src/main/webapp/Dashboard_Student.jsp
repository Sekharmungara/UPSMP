<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Dashboard-Student | UPSMP</title>
	<link rel="stylesheet" href="CSS/dashboard_student.css" />
	
    <!-- Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

</head>
<body>
	
<!-- ===== PART 1: LOGO & TITLE ===== -->
<header class="header-top">
    <div class="container d-flex align-items-center">
        <img src="https://play-lh.googleusercontent.com/dLCkcn513XWkcx3UmZGX15ARB7e4omD3wcX08tfBMddOM7UNB_Qf4oeQdkTFdnMTVgbq=w480-h960-rw"
             width="55" class="me-3" alt="Logo">
        <h4 class="mb-0 fw-bold" style="color: var(--primary-color);">
            University Problem–Solution Management Portal
        </h4>
    </div>
</header>

<!-- ===== PART 2: ROLE ===== -->
<section class="role-bar">
    <div class="container">
        <strong>Sekhar</strong> <span class="fw-normal">(Student)</span>
    </div>
</section>

<!-- ===== PART 3: MAIN ===== -->
<div class="container-fluid">
    <div class="row">

        <!-- LEFT MENU -->
        <div class="col-md-3 col-lg-2 sidebar p-0">
        
            <a href="./my_problems.jsp" class="active" onclick="loadDashboard()"> <i class="fas fa-chart-line me-2"></i> My Projects </a>
                
            <a href="./view_all_problems.jsp" class="#" onclick="loadProjects()"> <i class="fas fa-folder-open me-2"></i> All Projects </a>
                
            <a href="./Login.html" onclick="loadProjects()"> <i class="fas fa-sign-out-alt me-2"></i> Logout </a>
            
        </div>

        <!-- RIGHT CONTENT -->
        <div class="col-md-9 col-lg-10 content-area">
            <div id="mainContent"></div>
        </div>

    </div>
</div>

<!-- ===== SCRIPTS ===== -->
<script>
    // Load Dashboard by default
    window.onload = loadDashboard;

    function loadDashboard() {
        document.getElementById("mainContent").innerHTML = `
            <div class="table-card">
                <h5 class="fw-bold mb-3">My Dashboard</h5>
                <div class="table-responsive">
                    <table class="table table-bordered align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>P_ID</th>
                                <th>Name</th>
                                <th>Assigned To</th>
                                <th>Completion %</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>10</td>
                                <td>ABC</td>
                                <td>Sekhar</td>
                                <td>0%</td>
                                <td>
                                    <span class="badge bg-warning text-dark">Pending</span>
                                </td>
                                <td>
                                   <a href="#"> <i class="fas fa-pencil-alt text-primary" style='font-size:24px'> </i> </a>
                                </td>
                            </tr>
			<tr>
                                <td>11</td>
                                <td>xyz</td>
                                <td>sekhar</td>
                                <td>10%</td>
                                <td>
                                    <span class="badge bg-warning text-dark">inprogress</span>
                                </td>
                                <td>
                                   <a href="#"> <i class="fas fa-pencil-alt text-primary" style='font-size:24px'> </i> </a>
                                </td>
                            </tr>
			<tr>
                                <td>12</td>
                                <td>pqr</td>
                                <td>sekhar</td>
                                <td>100%</td>
                                <td>
                                    <span class="badge bg-warning text-dark">complete</span>
                                </td>
                                <td>
                                  <a href="#"> <i class="fas fa-pencil-alt text-primary" style='font-size:24px'> </i></a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    function loadProjects() {
        document.getElementById("mainContent").innerHTML = `
            <div class="table-card">
                <h5 class="fw-bold">All Projects</h5>
                <p class="text-muted">
                    This section will display all available university problem statements.
                </p>
            </div>
        `;
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
	
</body>
</html>