<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Send Request Controller | UPSMP</title>
</head>
<body>

	<%
	String uId = session.getAttribute("userId").toString();
	String name = session.getAttribute("userName").toString();
	
	System.out.println(uId);
    System.out.println(name);

	String problem_id = request.getParameter("problemId");
	int problemId = Integer.parseInt(problem_id);
	String solution = request.getParameter("solution");
	
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection  con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
			PreparedStatement ps = con.prepareStatement("UPDATE problem SET status='SUBMITTED', solution=?, submitted_by=?, student_name=? WHERE problem_id=?");
			 
			/* ps.setString(1, "SUBMITTED"); */
			ps.setString(1, solution);
			ps.setString(2, uId);
			ps.setString(3, name);
			ps.setInt(4, problemId);
			
			int i = ps.executeUpdate();
			
			if (i>0){
				response.sendRedirect("view_all_problems.jsp?msg=Send request Successfully&color=green");
			} else {
				response.sendRedirect("view_all_problems.jsp?msg=Send request failed&color=red");
			}
			con.close();
		} catch(Exception e) {e.printStackTrace();
			response.sendRedirect("view_all_problems.jsp?msg=Send request failed&color=red");
		}
	%>

</body>
</html>