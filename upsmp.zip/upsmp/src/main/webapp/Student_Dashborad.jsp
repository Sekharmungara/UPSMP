<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Student Dashboard | UPSMP</title>
<link rel="stylesheet" href="CSS/student_dashboard.css" />
	 <!-- Bootstrap & Icons -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

</head>
<body>

	<!-- ===== PART 1: LOGO & TITLE ===== -->
<header class="header-top">
    <div class="container d-flex align-items-center">
        <img src="https://surl.li/lmwgup"
             width="55" class="me-3" alt="Logo">
        <h2 class="mb-0 fw-bold" style="color: var(--primary-color);">
            UPSMP 
        </h2>
    </div>
</header>

<!-- ===== PART 2: ROLE NAME ===== -->
<section class="role-banner">
    <div class="container">
        <h5 class="mb-0">
            Welcome, Student <span class="fw-normal">(Student)</span>
        </h5>
    </div>
</section>

<!-- ===== PART 3: MAIN LAYOUT ===== -->
<div class="container-fluid">
    <div class="row">

        <!-- LEFT MENU -->
        <div class="col-md-3 col-lg-2 sidebar p-0">
        
            <a href="./my_problems.jsp" class="#" onclick="loadDashboard()"> <i class="fas fa-chart-line me-2"></i> My Projects </a>
                
            <a href="./view_all_problems.jsp" class="#" onclick="loadProjects()"> <i class="fas fa-folder-open me-2"></i> All Projects </a>
                
            <a href="./Login.html" onclick="loadProjects()"> <i class="fas fa-sign-out-alt me-2"></i> Logout </a>
                
        </div>

        <!-- RIGHT TARGET PAGE -->
        <div class="col-md-9 col-lg-10 content-area">
            <div class="row">
                <div class="col-lg-8">
                    <div class="card info-card">
                        <img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=1200"
                             class="card-img-top" alt="Student Projects">
                        <div class="card-body">
                            <h4 class="fw-bold">Student Project Dashboard</h4>
                            <p class="text-muted">
                                This section allows students to view assigned university problems,
                                track project progress, submit solutions, and communicate with
                                administrators and HODs. All activities are monitored for transparency
                                and academic evaluation.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card info-card p-4">
                        <h5 class="fw-bold">Quick Info</h5>
                        <ul class="mt-3">
                            <li>Assigned Projects: 2</li>
                            <li>Pending Reviews: 1</li>
                            <li>Approved Solutions: 0</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
	


</body>
</html>