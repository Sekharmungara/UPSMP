<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Review Solution | UPSMP</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">


</head>
<body>

	<%
	String userId = request.getParameter("problem_id");
	int problem_id = Integer.parseInt(userId);
	// System.out.println(userId);
	%>

	<!-- PART 1 : HEADER -->
	<section class="py-4 border-bottom bg-white">
		<div
			class="container d-flex justify-content-between align-items-center">
			<h2 class="fw-bold text-primary mb-0">Project Info</h2>

			<button class="btn btn-outline-primary" onclick="history.back()">
				Back</button>
		</div>
	</section>

	<%
	try {

		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "upsmp", "upsmp");
		PreparedStatement ps = con.prepareStatement("select problem_id ,title ,description ,solution ,submitted_by ,student_name from problem where problem_id=?");
		ps.setInt(1, problem_id);

		//System.out.println("working");
		ResultSet rs = ps.executeQuery();

		if (rs.next()) {
			int problemId = rs.getInt(1);
			//System.out.println(request.getQueryString());
	%>

	<!-- PART 2 : STUDENT INFO -->
	<form action="./review_solution_controller.jsp" method="post">
	<section class="container my-5">
		<div class="card data-card p-4">
			<h4 class="fw-bold text-primary mb-4">Student Information</h4>
			<div class="row g-3">
				<div class="col-md-4">
					<label class="form-label">Student ID</label> 
						<input type="text" class="form-control" name="studentId" value="<%=rs.getString(5)%>" disabled>
						 <input type="hidden" name="studentId" value="<%=rs.getString(5)%>">
				</div>

				<div class="col-md-4">
					<label class="form-label">Student Name</label> 
						<input type="text" class="form-control" name="studentName" value="<%=rs.getString(6)%>" disabled>
						
				</div>
			</div>
		</div>
	</section>
	
		<!-- PART 3 : PROJECT INFO (ADMIN ADDED) -->
		<section class="container mb-5">
			<div class="card data-card p-4">
				<h4 class="fw-bold text-primary mb-4">Project Information</h4>

				<div class="row g-3">
					<div class="col-md-4">
						<label class="form-label">Project ID</label> 
							<input type="text" class="form-control" name="problemId" value="<%=rs.getInt(1)%>" disabled>
							 <input type="hidden" name="problemId" value="<%=rs.getInt(1)%>"> 
					</div>

					<div class="col-md-8">
						<label class="form-label">Title</label> 
							<input type="text" class="form-control" name="title" value="<%=rs.getString(2)%>" disabled>
							 <input type="hidden" name="title" value="<%=rs.getString(2)%>"> 
					</div>

					<div class="col-12">
						<label class="form-label">Project Description </label>
						<textarea class="form-control" name="description" rows="4"  disabled> <%=rs.getString(3)%>  </textarea>
						 <input type="hidden" name="description" value="<%=rs.getString(3)%>"> 
					</div>
				</div>
			</div>
		</section>
	
	<!-- PART 4 : PROJECT SOLUTION (STUDENT SOLUTION) -->
	<section class="container mb-5">
		<div class="card data-card p-4">
			<h4 class="fw-bold text-primary mb-4">Project Solution (Student
				Submission)</h4>

			<textarea class="form-control" rows="6" disabled> <%=rs.getString(4)%> </textarea>
			 
			<h4 class="fw-bold text-primary mb-4">Comments</h4>

			<textarea class="form-control" name="comments" rows="6">
			
			 
			 </textarea>

		</div>
	</section>
	<!-- PART 5 : ACTION BUTTONS -->
	<section class="container mb-5">
		<div class="d-flex justify-content-end gap-3">
			<a href="./request_solution_controller.jsp"><button type="submit" class="btn btn-success px-4" onclick="acceptProject()">Accept</button></a>
			
			<a href="./reject_solution.jsp?problemId=<%=rs.getInt(1)%>" style="display:inline-block; background-color:red; color:white; padding:8px 18px;
          				text-decoration:none; border-radius:5px; font-weight:bold; text-align:center;" > Reject </a>
		</div>
	</section>
	</form>
	
	<%
	}
	} catch (Exception e) {
	e.printStackTrace();
	}
%>

	<footer class="bg-dark text-white text-center py-3">
		<small>&copy; 2026 UPSMP. All Rights Reserved.</small>
	</footer>

	<script>
		function acceptProject() {
			alert("Project Accepted Successfully");
			// Backend logic: update status = ACCEPTED
		}

		function rejectProject() {
			alert("Project Rejected");
			// Backend logic: update status = REJECTED
		}
	</script>

</body>
</html>