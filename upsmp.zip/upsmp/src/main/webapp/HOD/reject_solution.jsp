<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title> Reject Solution | UPSMP</title>
</head>
<body>
	<%
		String pId = request.getParameter("problemId");
		int problemId = Integer.parseInt(pId);
		
		String status = request.getParameter("status");
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
			PreparedStatement ps = con.prepareStatement("UPDATE problem SET status =? WHERE problem_id =?");
			ps.setString(1, status);
			ps.setInt(2, problemId);
			
			int i = ps.executeUpdate();
			
			if (i>0){
				response.sendRedirect("view_all_submitted_solutions.jsp?msg=Rejected Successfully&color=green");
			} else {
				response.sendRedirect("view_all_submitted_solutions.jsp?msg=Rejection failed&color=red");
			}
			
			con.close();
		} catch(Exception e) {e.printStackTrace();
		
			response.sendRedirect("view_all_submitted_solutions.jsp?msg=Rejection failed&color=red");
		}
	
	%>
</body>
</html>