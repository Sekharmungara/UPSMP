<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>View Problem Details | UPSMP</title>

	<!-- Bootstrap & Icons -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
	
	<!--CSS Link-->
	<link rel="stylesheet" href="../CSS/view_student_details.css" />
	
</head>
<body>

<%
	String problem_id = request.getParameter("problemId");
	int problemId = Integer.parseInt(problem_id); 
	// System.out.println(userId);


%>
	<!-- HEADER -->
	<header class="header-top">
		<div class="container d-flex align-items-center">
			<img
				src="https://surl.li/lmwgup"
				width="55" class="me-3">
			<h2 class="mb-0 fw-bold" style="color: var(--primary-color)">UPSMP</h2>
		</div>
	</header>

	<!-- ROLE -->
	<section class="role-banner">
		<div class="container">
			<h5 class="mb-0">
				Welcome, Hod <span class="fw-normal">(HOD)</span>
			</h5>
		</div>
	</section>

	<!-- MAIN -->
	<div class="container-fluid">
		<div class="row">

			<!-- SIDEBAR -->
			<div class="col-md-3 col-lg-2 sidebar p-0">

			<a href="./my_problems.jsp" class="#"> <i class="fas fa-chart-line me-2"></i> My Problems </a>
           
            <a href="./view_all_problems.jsp" class="#"> <i class="fas fa-folder-open me-2"></i> All Projects </a>
                
            <a href="./view_all_submitted_solutions.jsp" class="#"> <i class="fa-solid fa-lightbulb"></i>  Solution Submited </a>
               
            <a href="../Login.html" onclick="loadProjects()"> <i class="fas fa-sign-out-alt me-2"></i> Logout </a>

			</div>
		<%
	
		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
			PreparedStatement ps = con.prepareStatement("select problem_id,title,description,prob_type,dept_name,status from problem where problem_id=?");
			ps.setInt(1, problemId);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				int problems_id = rs.getInt(1); %>
				<!-- CONTENT -->
					<div class="col-md-9 col-lg-10 content-area">

					<div class="d-flex justify-content-between align-items-center mb-4">
						<h4 class="fw-bold text-primary">Problem Details</h4>
					</div>

					<div class="card data-card p-4">
				
					<form>

						<div class="row mb-4">
							<div class="col-md-6">
								<label class="form-label">Problem ID</label> <input type="text"
									class="form-control" value="<%=rs.getInt(1) %>" disabled>
							</div>

							<div class="col-md-6">
								<label class="form-label">Title</label> <input
									type="text" class="form-control" value="<%=rs.getString(2) %>" disabled>
							</div>
							
							<div class="col-md-6">
								<label class="form-label">Description</label>
								<%-- <input type="text" class="form-control" value="<%=rs.getString(3) %>" disabled> --%>
								 
								 <textarea class="form-control" name="description" rows="4" disabled> <%=rs.getString(3) %> </textarea>
							</div>
							
							<div class="col-md-6">
								<label class="form-label">Problem Type</label> <input type="text"
									class="form-control" value="<%=rs.getString(4) %>" disabled>
							</div>
						</div>

						<div class="row mb-4">
							
							<div class="col-md-6">
								<label class="form-label">Department Name</label> <input type="text"
									class="form-control" value="<%=rs.getString(5) %>" disabled>
							</div>
							
							<div class="col-md-6">
								<label class="form-label">Status</label> <input type="text"
									class="form-control" value="<%=rs.getString(6) %>" disabled>
							</div>

						</div>

						<div class="mt-4">

							<a href="./my_problems.jsp" class="btn btn-secondary"> <i
								class="fa-solid fa-arrow-left me-2"></i>Back
							</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<% }
			
		} catch(Exception e){e.printStackTrace();}
		%>
			
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>