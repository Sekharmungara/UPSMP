<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Add New Problem Controller | UPSMP</title>
</head>
<body>
		
	<%
		String P_title = request.getParameter("title");
		String p_description = request.getParameter("description");
		String problemType = request.getParameter("problem_type").toUpperCase();
		String deptName = request.getParameter("department");
		/* String status = request.getParameter("status"); */
		
		/* System.out.println(P_title);
		System.out.println(p_description);
		System.out.println(problemType);
		System.out.println(deptName);
		System.out.println(status);  */
		
		
		// SESSION
		int uId = 0;

		if(session.getAttribute("userId") != null){
		    uId = Integer.parseInt(session.getAttribute("userId").toString());
		}else{
		    out.println("Session expired. Please login again.");
		    return;
		}
		
		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
			PreparedStatement ps = con.prepareStatement("insert into problem (problem_id,title,description,prob_type,dept_name,status,created_by) values(problem_id_seq.nextval,?,?,?,?,'OPEN',?)");
			
			ps.setString(1, P_title);
			ps.setString(2, p_description);
			ps.setString(3, problemType);
			
			// dept logic
			if(problemType.equals("UNIVERSITY")){
			    ps.setNull(4, java.sql.Types.VARCHAR);
			}else{
			    ps.setString(4, deptName);
			}
			/* ps.setString(6, status); */
			ps.setInt(5, uId);
			
			//ps.setString(4, deptName);
			
	 		int i = ps.executeUpdate();
	 		
			if (i>0){
				response.sendRedirect("my_problems.jsp?msg=Problem added Successfully&color=green");
			} else {
				response.sendRedirect("my_problems.jsp?msg=Problem adding failed&color=red");
			}
			
			con.close();
			
		} catch(Exception e){e.printStackTrace();
			response.sendRedirect("my_problems.jsp?msg=Problem adding failed&color=red");
		}
		
		%>
		
</body>
</html>