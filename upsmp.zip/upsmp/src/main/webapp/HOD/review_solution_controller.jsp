<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Review solution Controller | UPSMP</title>
</head>
<body>

	<%
		String pId = request.getParameter("problemId");
		int problemId = Integer.parseInt(pId);
		
		String sId = request.getParameter("studentId");
		int studentId = Integer.parseInt(sId);
		
		String P_title = request.getParameter("title");
		String p_description = request.getParameter("description");
		String comment = request.getParameter("comments");
		
		/* System.out.println(problemId);
		System.out.println(studentId);
		System.out.println(P_title);
		System.out.println(p_description);
		System.out.println(comment); */
		

			try{
	
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
				PreparedStatement ps = con.prepareStatement("insert into assigned_problems (assigned_prob_id,problem_id,student_id,title,description,comments,status,created_at,updated_at) values(ASSIGNED_PROBLEMS_SEQ.nextval,?,?,?,?,?,'TO DO',SYSDATE,SYSDATE)");
	
				ps.setInt(1, problemId);
				ps.setInt(2, studentId);
				ps.setString(3, P_title);
				ps.setString(4, p_description);
				ps.setString(5, comment);
				
	
				int i = ps.executeUpdate();
		
				if (i>0){
					PreparedStatement ps2 = con.prepareStatement("update problem set status='ASSIGNED' where problem_id=?");
					ps2.setInt(1, problemId);
					
					int j = ps2.executeUpdate();
					
					if(j > 0){
						response.sendRedirect("view_all_submitted_solutions.jsp?msg=Assigned Successfully&color=green");
					}
					
					
				} else {
					response.sendRedirect("view_all_submitted_solutions.jsp?msg=Assign failed&color=red");
				}
	
				con.close();
	
				} catch(Exception e){e.printStackTrace();
					response.sendRedirect("view_all_submitted_solutions.jsp?msg=Assign failed&color=red");
				}
	
	%>

</body>
</html>