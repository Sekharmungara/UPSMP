<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Update Problem Details Controller | UPSMP</title>
</head>
<body>
	
	<%
	String problem_id = request.getParameter("problemId");
	int problemId = Integer.parseInt(problem_id);
	String P_title = request.getParameter("title");
	String p_description = request.getParameter("description");
	String problemType = request.getParameter("problem_type");
	String deptName = request.getParameter("department");
	String status = request.getParameter("status");
	
 	/* System.out.println(problemId);
	System.out.println(P_title);
	System.out.println(p_description);
	System.out.println(problemType);
	System.out.println(deptName);
	System.out.println(status);  */
	
	try{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
		PreparedStatement ps = con.prepareStatement("DELETE from problem WHERE problem_id =?");
		ps.setInt(1, problemId);
		/* ps.setString(2, s_name);
		ps.setString(3, s_email);
		ps.setString(4, s_password);
		ps.setString(5, s_role);
		ps.setString(6, s_department);
		ps.setString(7, mobile_no);
		ps.setString(8, s_address);
		ps.setString(9, s_gender); */
		
		int i = ps.executeUpdate();
		
		if (i>0){
			out.println("Deleted Successfully");
		} else {
			out.println("Delition Failed");
		}
		
		con.close();
	} catch(Exception e){e.printStackTrace();}
	
	
	%>
	
</body>
</html>