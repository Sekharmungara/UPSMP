<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Update Problem Details Controller | UPSMP</title>

	<!-- Bootstrap & Icons -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
	
	<!--CSS Link-->
	<link rel="stylesheet" href="./CSS/view_student_details.css" />
	
</head>
<body>

<%
	String problem_id = request.getParameter("problemId");
	int problemId = Integer.parseInt(problem_id);
	
	String status = request.getParameter("status");
	
	/* System.out.println(problemId);
	System.out.println(P_title);
	System.out.println(p_description);
	System.out.println(problemType);
	System.out.println(deptName);
	System.out.println(status); */
	
		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","upsmp","upsmp");
			PreparedStatement ps = con.prepareStatement("UPDATE assigned_problems SET status =? WHERE problem_id =?");
			
			ps.setString(1, status);
			ps.setInt(2, problemId);
			
			
			int i = ps.executeUpdate();
			
			if (i>0){
				response.sendRedirect("my_problems.jsp?msg=Project status updated Successfully&color=green");
			} else {
				response.sendRedirect("my_problems.jsp?msg=Project status updated failed&color=red");
			}
			
			con.close();
		} catch(Exception e){e.printStackTrace();
			response.sendRedirect("my_problems.jsp?msg=Project status updated failed&color=red");
		}
	%>
	
</body>
</html>